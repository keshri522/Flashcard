
import React from "react";
import { useNavigate } from 'react-router-dom'
import MyFlahsCard from "../Page/Myflashcard";

const SingleFlashCard = ({ FlashCard }) => {

   
   let navigate = useNavigate();
   return (
      <div className="container cards my-4   " >
         <div
            key={FlashCard.titleId} className=" text-center  mx-2 my-4 " style={{ width: "15rem" }}>

            {FlashCard.titleimg ? (
               <img className="image-display " src={FlashCard.titleimg} alt={FlashCard.titleimg}
               />
            ) : (
               <img className="image-display" src="https://cdn.britannica.com/05/94905-050-1830515C/Whirlpool-Galaxy-NGC-5195-Sc.jpg"
                  alt={FlashCard.titleimg}
               />
            )
            }
            <div className="containers    text-center">

               <h5 className=" font-weight-bold mt-2     text-info">
                  {FlashCard.titlename}
               </h5>
               <p className="text-secondary text-wrap badge">{FlashCard.titledescription}</p>
               <p className="font text-primary">{FlashCard.Card ? FlashCard.Card.length : 0} Cards </p>
            </div>
            <div className="  d-flex justify-content-around ">
               <div className=" ">
                  <button onClick={() => {
                     navigate('/myflashcardDetails/${FlashCard.titleId}')
                     console.log(FlashCard.titleId);
                  }}
                     className=" btns   ">
                     Show Cards
                  </button>
               </div>
               <div>
                  <button 
              onClick={(()=>{
               console.log(FlashCard.titleId);
              })}
                     className=" btnss  "  >
            
                     Remove card
                  </button>
               </div>
            </div>
         </div>
      </div>
   );
};
export default SingleFlashCard;