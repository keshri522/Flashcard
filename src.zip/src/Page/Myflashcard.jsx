// this is MyFlahsCard page all the created Flahscard will show here..
import React from "react";
import { useSelector } from "react-redux";
import SingleFlashCard from "../Components/SingleFlashCard";
import { useNavigate } from "react-router";

const MyFlahsCard=()=>{

const Delete=(id)=>{
  console.log("My id" ,id)
}

    const navigate=useNavigate();
    const FlahsCard=useSelector((state)=>state.FlahsCard);
    console.log("Data" ,FlahsCard);

        return (
          <div className="container pt-3 ">
          <div className="col-md-12">
          <div className=" bg-light display-flex" >
             {FlahsCard.Cards.map((FlahsCard,index)=>{
         
              return  <SingleFlashCard  delete={Delete} key={index} FlashCard={FlahsCard}></SingleFlashCard>
             })}
       
             </div>
          </div>
       
          </div>
        )
    
}
   
export default MyFlahsCard;